"""Pure calculations for the market brief data job. No network access here.

Market type follows Van Tharp: the System Quality Number (SQN) of the
S&P 500's daily % changes gives direction; the 20-day ATR as a % of price,
measured in standard deviations from its long-run mean, gives volatility.
"""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

# Direction bands for SQN of daily % changes (Van Tharp, 2018 SQN report).
STRONG_BULL = 1.47
BULL = 0.70
BEAR = -0.70
# Volatility bands: z-score of 20-day ATR% against its long-run history.
VOL_LOW = -0.5
VOL_HIGH = 0.5
VOL_VERY = 3.0
ATR_DAYS = 20
SQN_WINDOWS = (25, 50, 100, 200)
# Volume rules.
AVG_DAYS = 50          # volume baseline: previous 50 sessions
RVOL_HOT = 1.5         # heavy volume: accumulation / distribution counts
UNUSUAL_RVOL = 2.0     # unusual volume list
UNUSUAL_TOP = 15
DIST_DROP = -0.2       # S&P 500 % fall that can make a distribution day
DIST_WINDOW = 25


def _num(x, digits: int):
    """Round to a JSON-safe float, or None for missing values."""
    if x is None:
        return None
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    if math.isnan(v) or math.isinf(v):
        return None
    return round(v, digits)


def sqn(returns) -> float:
    """SQN = sqrt(min(N, 100)) * mean / sample standard deviation."""
    r = np.asarray(returns, dtype=float)
    r = r[~np.isnan(r)]
    n = len(r)
    if n < 2:
        return float("nan")
    sd = r.std(ddof=1)
    if sd == 0 or math.isnan(sd):
        return float("nan")
    return math.sqrt(min(n, 100)) * r.mean() / sd


def direction(s) -> str:
    if s is None or (isinstance(s, float) and math.isnan(s)):
        return "Unknown"
    if s > STRONG_BULL:
        return "Strong Bull"
    if s >= BULL:
        return "Bull"
    if s >= 0:
        return "Sideways"
    if s >= BEAR:
        return "Bear"
    return "Strong Bear"


def vol_class(z) -> str:
    if z is None or (isinstance(z, float) and math.isnan(z)):
        return "Unknown"
    if z > VOL_VERY:
        return "Very Volatile"
    if z > VOL_HIGH:
        return "Volatile"
    if z >= VOL_LOW:
        return "Normal"
    return "Quiet"


def true_range(df: pd.DataFrame) -> pd.Series:
    prev = df["Close"].shift(1)
    parts = pd.concat(
        [df["High"] - df["Low"], (df["High"] - prev).abs(), (df["Low"] - prev).abs()], axis=1
    )
    return parts.max(axis=1)


def atr_pct(df: pd.DataFrame, n: int = ATR_DAYS) -> pd.Series:
    return true_range(df).rolling(n).mean() / df["Close"] * 100


def clean_index(idx: pd.DataFrame) -> pd.DataFrame:
    """Drop rows without a close and early rows where high = low = close (no real range)."""
    idx = idx.dropna(subset=["Close"]).sort_index()
    flat = (idx["High"] == idx["Low"]) & (idx["Low"] == idx["Close"])
    return idx.loc[~flat]


def market_type_history(idx: pd.DataFrame, last_n: int = 260) -> list[dict]:
    """One row per session for the last `last_n` sessions."""
    idx = clean_index(idx)
    rets = idx["Close"].pct_change() * 100
    atr = atr_pct(idx)
    hist = atr.dropna()
    mu, sd = hist.mean(), hist.std(ddof=1)
    rows = []
    start = max(0, len(idx) - last_n)
    for i in range(start, len(idx)):
        window = rets.iloc[: i + 1].dropna()
        vals = {f"sqn{w}": _num(sqn(window.iloc[-w:].to_numpy()), 3) if len(window) >= w else None for w in SQN_WINDOWS}
        a = atr.iloc[i]
        z = (a - mu) / sd if sd and not math.isnan(a) else float("nan")
        d = direction(vals["sqn100"] if vals["sqn100"] is not None else float("nan"))
        v = vol_class(z)
        rows.append({
            "session": idx.index[i].strftime("%Y-%m-%d"),
            **vals,
            "direction": d,
            "atr_pct": _num(a, 3),
            "atr_z": _num(z, 2),
            "volatility": v,
            "label": f"{d} · {v}",
        })
    return rows


def flows(
    closes: pd.DataFrame,
    volumes: pd.DataFrame,
    sectors: dict,
    names: dict,
    index_close: pd.Series,
    market_back: int = 60,
    detail_back: int = 20,
) -> tuple[list[dict], list[dict], list[dict]]:
    """Market, sector and unusual-volume rows from member closes and volumes.

    closes / volumes: dates x tickers. index_close: S&P 500 closes on the same dates.
    """
    closes = closes.sort_index()
    volumes = volumes.reindex(index=closes.index, columns=closes.columns)
    index_close = index_close.reindex(closes.index)

    rets = closes.pct_change(fill_method=None) * 100
    avg = volumes.rolling(AVG_DAYS, min_periods=AVG_DAYS).mean().shift(1)
    rvol = volumes / avg
    sma50 = closes.rolling(50, min_periods=50).mean()
    sma200 = closes.rolling(200, min_periods=200).mean()
    dollar = closes * volumes

    agg = volumes.sum(axis=1, min_count=1)
    agg_avg = agg.rolling(AVG_DAYS, min_periods=AVG_DAYS).mean().shift(1)
    idx_ret = index_close.pct_change(fill_method=None) * 100
    dist_day = (idx_ret <= DIST_DROP) & (agg > agg.shift(1))
    dist_count = dist_day.astype(float).rolling(DIST_WINDOW, min_periods=DIST_WINDOW).sum()

    sector_of = pd.Index(closes.columns).map(lambda t: sectors.get(t))
    dv_sector = dollar.T.groupby(sector_of).sum(min_count=1).T
    share = dv_sector.div(dv_sector.sum(axis=1), axis=0) * 100
    share_avg = share.rolling(AVG_DAYS, min_periods=AVG_DAYS).mean().shift(1)
    vol_sector = volumes.T.groupby(sector_of).sum(min_count=1).T
    vol_sector_avg = vol_sector.rolling(AVG_DAYS, min_periods=AVG_DAYS).mean().shift(1)

    market_rows, sector_rows, unusual_rows = [], [], []
    dates = closes.index
    for pos in range(max(0, len(dates) - market_back), len(dates)):
        d = dates[pos]
        s = d.strftime("%Y-%m-%d")
        r = rets.loc[d]
        valid = r.dropna()
        adv = int((valid > 0).sum())
        dec = int((valid < 0).sum())
        c = closes.loc[d]
        a50 = (c > sma50.loc[d])[sma50.loc[d].notna() & c.notna()]
        a200 = (c > sma200.loc[d])[sma200.loc[d].notna() & c.notna()]
        market_rows.append({
            "session": s,
            "agg_volume": _num(agg.loc[d], 0),
            "avg50_volume": _num(agg_avg.loc[d], 0),
            "rvol": _num(agg.loc[d] / agg_avg.loc[d] if agg_avg.loc[d] else float("nan"), 3),
            "adv": adv,
            "dec": dec,
            "breadth_pct": _num(adv / len(valid) * 100 if len(valid) else float("nan"), 1),
            "above50_pct": _num(a50.mean() * 100 if len(a50) else float("nan"), 1),
            "above200_pct": _num(a200.mean() * 100 if len(a200) else float("nan"), 1),
            "dist_days_25": _num(dist_count.loc[d], 0),
            "spx_change_pct": _num(idx_ret.loc[d], 3),
        })
        if pos < len(dates) - detail_back:
            continue
        rv = rvol.loc[d]
        for sec in sorted(x for x in set(sector_of) if isinstance(x, str)):
            members = [t for t in closes.columns if sectors.get(t) == sec]
            mr = r[members].dropna()
            mrv = rv[members]
            hot = mrv >= RVOL_HOT
            sector_rows.append({
                "session": s,
                "sector": sec,
                "n": int(len(mr)),
                "ret_pct": _num(mr.mean() if len(mr) else float("nan"), 3),
                "rvol": _num(vol_sector.loc[d, sec] / vol_sector_avg.loc[d, sec] if vol_sector_avg.loc[d, sec] else float("nan"), 3),
                "dv_share_pct": _num(share.loc[d, sec], 3),
                "dv_share_50_pct": _num(share_avg.loc[d, sec], 3),
                "share_chg_pp": _num(share.loc[d, sec] - share_avg.loc[d, sec], 3),
                "n_accum": int(((r[members] > 0) & hot).sum()),
                "n_distrib": int(((r[members] < 0) & hot).sum()),
            })
        unusual = rv[rv >= UNUSUAL_RVOL].dropna().sort_values(ascending=False).head(UNUSUAL_TOP)
        for t, x in unusual.items():
            unusual_rows.append({
                "session": s,
                "ticker": t,
                "name": names.get(t),
                "sector": sectors.get(t),
                "ret_pct": _num(r.get(t), 3),
                "rvol": _num(x, 3),
                "dollar_volume": _num(dollar.loc[d, t], 0),
            })
    return market_rows, sector_rows, unusual_rows
