"""Downloads for the data job. Runs on GitHub Actions, which has open internet access."""
from __future__ import annotations

import io
import time

import pandas as pd
import requests

CONSTITUENTS_URL = "https://raw.githubusercontent.com/datasets/s-and-p-500-companies/main/data/constituents.csv"
STOOQ_SPX = "https://stooq.com/q/d/l/?s=%5Espx&i=d"
FIELDS = ["Open", "High", "Low", "Close", "Volume"]


def constituents() -> pd.DataFrame:
    text = requests.get(CONSTITUENTS_URL, timeout=60).text
    df = pd.read_csv(io.StringIO(text))
    df["yahoo"] = df["Symbol"].astype(str).str.replace(".", "-", regex=False)
    return df


def _flatten_single(df: pd.DataFrame) -> pd.DataFrame:
    """yfinance may return (field, ticker) columns even for one ticker."""
    if isinstance(df.columns, pd.MultiIndex):
        df = df.copy()
        df.columns = df.columns.get_level_values(0)
    return df


def index_history(start: str = "1962-01-01") -> tuple[pd.DataFrame, str]:
    """S&P 500 daily OHLC. Yahoo first, Stooq as a fallback."""
    import yfinance as yf

    for attempt in range(3):
        try:
            df = yf.download("^GSPC", start=start, auto_adjust=False, progress=False, threads=False)
            df = _flatten_single(df)
            if len(df) > 5000 and set(FIELDS[:4]).issubset(df.columns):
                df.index = pd.to_datetime(df.index).tz_localize(None)
                return df[[c for c in FIELDS if c in df.columns]], "Yahoo Finance (^GSPC)"
        except Exception as exc:  # network or parsing failure: retry, then fall back
            print(f"Yahoo index attempt {attempt + 1} failed: {exc}")
        time.sleep(10 * (attempt + 1))
    text = requests.get(STOOQ_SPX, timeout=120).text
    df = pd.read_csv(io.StringIO(text), parse_dates=["Date"], index_col="Date")
    return df[[c for c in FIELDS if c in df.columns]], "Stooq (^SPX)"


def members_history(tickers: list[str], period: str = "2y", chunk: int = 100) -> tuple[pd.DataFrame, pd.DataFrame, list[str]]:
    """Daily closes and volumes for many tickers, downloaded in chunks with retries."""
    import yfinance as yf

    closes, volumes, failed = [], [], []
    for i in range(0, len(tickers), chunk):
        part = tickers[i : i + chunk]
        df = None
        for attempt in range(3):
            try:
                df = yf.download(part, period=period, auto_adjust=False, progress=False, threads=True, group_by="column")
                if df is not None and not df.empty:
                    break
            except Exception as exc:
                print(f"Yahoo chunk {i // chunk + 1} attempt {attempt + 1} failed: {exc}")
            time.sleep(15 * (attempt + 1))
        if df is None or df.empty or not isinstance(df.columns, pd.MultiIndex):
            failed.extend(part)
            continue
        c = df["Close"]
        v = df["Volume"]
        got = [t for t in part if t in c.columns and c[t].notna().any()]
        failed.extend(t for t in part if t not in got)
        closes.append(c[got])
        volumes.append(v[got])
        time.sleep(2)
    if not closes:
        raise RuntimeError("No member prices downloaded")
    C = pd.concat(closes, axis=1)
    V = pd.concat(volumes, axis=1)
    C.index = pd.to_datetime(C.index).tz_localize(None)
    V.index = pd.to_datetime(V.index).tz_localize(None)
    return C, V, failed
