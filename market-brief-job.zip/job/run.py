"""Entry point: python -m job.run

Writes derived metrics only (no raw price files) to data/:
  market_type.json, flows_market.json, flows_sectors.json, flows_unusual.json, status.json
"""
from __future__ import annotations

import datetime as dt
import json
import os
from pathlib import Path

from job import compute, fetch

OUT = Path(os.environ.get("MB_OUT", "data"))


def write(name: str, rows) -> None:
    OUT.mkdir(exist_ok=True)
    (OUT / name).write_text(json.dumps(rows, ensure_ascii=False, separators=(",", ":"), allow_nan=False))


def main() -> None:
    status = {"generated_at": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "warnings": []}

    idx, source = fetch.index_history()
    status["index_source"] = source
    mt = compute.market_type_history(idx, last_n=260)
    write("market_type.json", mt)
    status["last_session"] = mt[-1]["session"] if mt else None
    status["market_type"] = mt[-1] if mt else None

    try:
        cons = fetch.constituents()
        tickers = cons["yahoo"].tolist()
        closes, volumes, failed = fetch.members_history(tickers)
        sectors = dict(zip(cons["yahoo"], cons["GICS Sector"]))
        names = dict(zip(cons["yahoo"], cons["Security"]))
        common = closes.index.intersection(idx.index)
        closes, volumes = closes.loc[common], volumes.loc[common]
        market, sector_rows, unusual = compute.flows(closes, volumes, sectors, names, idx["Close"])
        last = closes.index[-1].strftime("%Y-%m-%d")
        n_last = int(closes.iloc[-1].notna().sum())
        status.update(members=len(tickers), members_with_prices=n_last, failed_tickers=failed[:50], flows_session=last)
        if n_last < 450:
            status["warnings"].append(f"Only {n_last} of {len(tickers)} members have a close for {last}")
        if last != status["last_session"]:
            status["warnings"].append(f"Member data ends {last}, index data ends {status['last_session']}")
        write("flows_market.json", market)
        write("flows_sectors.json", sector_rows)
        write("flows_unusual.json", unusual)
    except Exception as exc:  # keep the market type even if the member download fails
        status["warnings"].append(f"Flows failed: {exc}")

    write("status.json", status)
    print(json.dumps(status, indent=1))


if __name__ == "__main__":
    main()
