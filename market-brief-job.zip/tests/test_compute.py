import json
import math

import numpy as np
import pandas as pd
import pytest

from job import compute as c


def test_sqn_formula():
    r = [1.0, 2.0, 3.0, 4.0]
    expected = math.sqrt(4) * np.mean(r) / np.std(r, ddof=1)
    assert c.sqn(r) == pytest.approx(expected)


def test_sqn_caps_n_at_100():
    rng = np.random.default_rng(1)
    r = rng.normal(0.05, 1.0, 400)
    expected = 10 * r.mean() / r.std(ddof=1)
    assert c.sqn(r) == pytest.approx(expected)


@pytest.mark.parametrize("s,label", [
    (1.48, "Strong Bull"), (1.47, "Bull"), (0.70, "Bull"), (0.69, "Sideways"),
    (0.0, "Sideways"), (-0.01, "Bear"), (-0.70, "Bear"), (-0.71, "Strong Bear"),
])
def test_direction_bands(s, label):
    assert c.direction(s) == label


@pytest.mark.parametrize("z,label", [
    (-0.51, "Quiet"), (-0.5, "Normal"), (0.5, "Normal"), (0.51, "Volatile"), (3.0, "Volatile"), (3.01, "Very Volatile"),
])
def test_vol_bands(z, label):
    assert c.vol_class(z) == label


def test_true_range_uses_previous_close():
    df = pd.DataFrame({"High": [10, 12, 11], "Low": [9, 11, 8], "Close": [9.5, 11.5, 10]})
    tr = c.true_range(df)
    assert tr.tolist() == [1, 2.5, 3.5]


def synthetic_index(n=2000, drift=0.03, seed=7):
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2018-01-01", periods=n)
    close = 1000 * np.exp(np.cumsum(rng.normal(drift / 100, 0.01, n)))
    high = close * (1 + rng.uniform(0.001, 0.01, n))
    low = close * (1 - rng.uniform(0.001, 0.01, n))
    return pd.DataFrame({"Open": close, "High": high, "Low": low, "Close": close, "Volume": 1e9}, index=dates)


def test_market_type_rows_are_complete_and_json_safe():
    rows = c.market_type_history(synthetic_index(), last_n=30)
    assert len(rows) == 30
    keys = {"session", "sqn25", "sqn50", "sqn100", "sqn200", "direction", "atr_pct", "atr_z", "volatility", "label"}
    for r in rows:
        assert keys <= set(r)
        assert r["label"] == f"{r['direction']} · {r['volatility']}"
    json.dumps(rows, allow_nan=False)


def test_market_type_matches_manual_sqn():
    idx = synthetic_index()
    rows = c.market_type_history(idx, last_n=1)
    r = idx["Close"].pct_change().mul(100).dropna().iloc[-100:].to_numpy()
    assert rows[-1]["sqn100"] == pytest.approx(round(10 * r.mean() / r.std(ddof=1), 3))


def test_strong_uptrend_reads_strong_bull():
    rows = c.market_type_history(synthetic_index(drift=0.6, seed=3), last_n=1)
    assert rows[-1]["direction"] == "Strong Bull"


def synthetic_members(n_days=320, seed=11):
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2025-01-01", periods=n_days)
    tickers = [f"T{i}" for i in range(12)]
    sectors = {t: ["Energy", "Utilities", "Information Technology"][i % 3] for i, t in enumerate(tickers)}
    names = {t: f"Company {t}" for t in tickers}
    closes = pd.DataFrame(100 * np.exp(np.cumsum(rng.normal(0, 0.01, (n_days, 12)), axis=0)), index=dates, columns=tickers)
    volumes = pd.DataFrame(rng.uniform(1e6, 2e6, (n_days, 12)), index=dates, columns=tickers)
    volumes.iloc[-1, 0] = 9e6  # one unusual spike on the last day
    index_close = closes.mean(axis=1)
    return closes, volumes, sectors, names, index_close


def test_flows_shapes_and_values():
    closes, volumes, sectors, names, index_close = synthetic_members()
    market, sectors_rows, unusual = c.flows(closes, volumes, sectors, names, index_close, market_back=60, detail_back=20)
    assert len(market) == 60
    assert len(sectors_rows) == 20 * 3
    last = market[-1]
    assert last["adv"] + last["dec"] <= 12
    day = [r for r in sectors_rows if r["session"] == last["session"]]
    assert sum(r["dv_share_pct"] for r in day) == pytest.approx(100, abs=1e-6)
    assert any(r["ticker"] == "T0" and r["rvol"] >= c.UNUSUAL_RVOL for r in unusual if r["session"] == last["session"])
    expected_rvol = volumes.iloc[-1, 0] / volumes.iloc[-51:-1, 0].mean()
    t0 = next(r for r in unusual if r["session"] == last["session"] and r["ticker"] == "T0")
    assert t0["rvol"] == pytest.approx(round(expected_rvol, 3))
    json.dumps([market, sectors_rows, unusual], allow_nan=False)


def test_distribution_day_count():
    closes, volumes, sectors, names, index_close = synthetic_members()
    # Force the last 25 sessions: index down 1% each day on rising volume.
    idx = index_close.copy()
    for k in range(25, 0, -1):
        idx.iloc[-k] = idx.iloc[-k - 1] * 0.99
    vol = volumes.copy()
    for k in range(26, 0, -1):
        vol.iloc[-k] = vol.iloc[-k - 1] * 1.01
    market, _, _ = c.flows(closes, vol, sectors, names, idx, market_back=1, detail_back=1)
    assert market[-1]["dist_days_25"] == 25


def test_scoreboard_rows_close_change_and_week_start():
    days = pd.bdate_range("2026-10-26", "2026-11-13")  # three full weeks, Mon 26 Oct to Fri 13 Nov
    closes = pd.DataFrame({"SOX": np.arange(100.0, 100.0 + len(days)), "VIX": 20.0}, index=days)
    closes.loc[pd.Timestamp("2026-11-11"), "SOX"] = np.nan  # a missing day for one index
    closes["DEAD"] = np.nan  # an index with no data is left out
    rows = c.scoreboard_rows(closes, {"SOX": "Chip index (SOX)", "VIX": "VIX"}, last_n=8)
    assert {r["id"] for r in rows} == {"SOX", "VIX"}
    sox = [r for r in rows if r["id"] == "SOX"]
    assert len(sox) == 8 and sox[-1]["session"] == "2026-11-13"
    assert sox[-1] == {"session": "2026-11-13", "id": "SOX", "name": "Chip index (SOX)",
                       "close": 114.0, "change_pct": round((114 / 113 - 1) * 100, 2), "week_start_close": 109.0}
    nov12 = next(r for r in sox if r["session"] == "2026-11-12")
    assert nov12["change_pct"] == round((113 / 111 - 1) * 100, 2)  # from Tuesday's close, Wednesday is missing
    assert next(r for r in sox if r["session"] == "2026-11-09")["week_start_close"] == 109.0  # Fri 6 Nov
    assert next(r for r in rows if r["id"] == "VIX" and r["session"] == "2026-11-13")["change_pct"] == 0.0
    assert [r["session"] for r in rows] == sorted(r["session"] for r in rows)
    json.dumps(rows, allow_nan=False)
