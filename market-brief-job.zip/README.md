# Market brief data

Data job for a daily US market brief. After each US close it computes:

- **Market type** (Van Tharp): SQN of S&P 500 daily % changes over 25/50/100/200 sessions; direction bands 1.47 / 0.70 / 0 / -0.70; volatility from 20-day ATR% in standard deviations from its long-run mean (quiet below -0.5, normal to +0.5, volatile above, very volatile beyond +3).
- **Volume and flows** for S&P 500 members: volume vs 50-day average, breadth, share above 50/200-day averages, distribution days (index down at least 0.2% on higher volume, last 25 sessions), sector share of dollar volume vs its 50-day average, stocks up or down on heavy volume (at least 1.5x), and unusual volume (at least 2x).

Only derived metrics are stored in `data/` (no raw price files).

| File | Rows |
|---|---|
| `data/market_type.json` | one per session, last 260 sessions |
| `data/indexes.json` | closes for the scoreboard (S&P 500, Nasdaq, Dow, Russell 2000, SOX, VIX): close, day change, previous week's last close; one per index per session, last 260 sessions |
| `data/flows_market.json` | one per session, last 60 sessions |
| `data/flows_sectors.json` | one per sector per session, last 20 sessions |
| `data/flows_unusual.json` | up to 15 per session, last 20 sessions |
| `data/status.json` | last run: time, sessions covered, warnings |

The workflow in `.github/workflows/daily.yml` runs at 23:15 UTC Monday to Friday, with a backup run at 03:15 UTC. It runs the code in `job/`, or unzips `market-brief-job.zip` when the code was uploaded as a zip. Run it by hand from the Actions tab (Run workflow).

Sources: Yahoo Finance via `yfinance` (Stooq as fallback for the index); S&P 500 members from `datasets/s-and-p-500-companies`. Not investment advice.
